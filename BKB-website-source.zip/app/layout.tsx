import type { Metadata, Viewport } from 'next';
import { Cormorant_Garamond, Inter } from 'next/font/google';
import './globals.css';

const serif = Cormorant_Garamond({ variable: '--font-serif', subsets: ['latin'], weight: ['400', '500', '600'], style: ['normal', 'italic'] });
const sans = Inter({ variable: '--font-sans', subsets: ['latin'] });
const siteUrl = 'https://bkb-belal-kabul-bakhtar.ahmadsuhil4.chatgpt.site';

export const metadata: Metadata = {
  metadataBase: new URL(siteUrl),
  title: 'BKB — Belal Kabul Bakhtar',
  description: 'A diversified Afghan business group active across international trade, commodities, financial services and distribution.',
  applicationName: 'BKB',
  category: 'business',
  alternates: { canonical: siteUrl },
  openGraph: {
    type: 'website',
    locale: 'en_US',
    siteName: 'BKB — Belal Kabul Bakhtar',
    title: 'BKB — Trade that moves across borders',
    description: 'An established Afghan business group connecting regional markets through trade, commodities, financial services and distribution.',
    url: siteUrl,
    images: [{
      url: `${siteUrl}/og.png`,
      width: 1731,
      height: 909,
      alt: 'BKB — Trade that moves across borders',
    }],
  },
  twitter: {
    card: 'summary_large_image',
    title: 'BKB — Trade that moves across borders',
    description: 'An established Afghan business group connecting regional markets through trade, commodities, financial services and distribution.',
    images: [`${siteUrl}/og.png`],
  },
  robots: { index: true, follow: true },
};

export const viewport: Viewport = {
  themeColor: '#F3F0E9',
  colorScheme: 'light',
};

export default function RootLayout({ children }: Readonly<{ children: React.ReactNode }>) {
  return <html lang="en"><body className={`${serif.variable} ${sans.variable}`}>{children}</body></html>;
}
