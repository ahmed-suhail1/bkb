'use client';

import { useEffect, useRef, useState } from 'react';

const images = {
  port: 'https://images.unsplash.com/photo-1759272840712-c7e5ea852367?auto=format&fit=crop&q=85&w=2000',
  wheat: 'https://images.unsplash.com/photo-1594588976857-2bc3b2380864?auto=format&fit=crop&q=85&w=1800',
  sunflower: 'https://images.unsplash.com/photo-1697098147393-15febb39a9b4?auto=format&fit=crop&q=85&w=1800',
  kabul: 'https://images.unsplash.com/photo-1659553958513-f08943d5fc30?auto=format&fit=crop&q=85&w=2000',
  rice: 'https://images.unsplash.com/photo-1764022122155-c2fa00a5fc44?auto=format&fit=crop&q=85&w=1600',
  sugar: 'https://images.unsplash.com/photo-1709651808265-977ed7ef78c6?auto=format&fit=crop&q=85&w=1600',
  warehouse: 'https://images.unsplash.com/photo-1749244768351-2726dc23d26c?auto=format&fit=crop&q=85&w=1800',
  freight: 'https://images.unsplash.com/photo-1765574781768-e7eda786846e?auto=format&fit=crop&q=85&w=2000',
};

const marketPrices = [
  { name: 'Wheat', value: '$286.40 / MT', change: '+0.8%', direction: 'up' },
  { name: 'Sunflower oil', value: '$1,052 / MT', change: '-0.4%', direction: 'down' },
  { name: 'Rice', value: '$517 / MT', change: '+1.2%', direction: 'up' },
  { name: 'Sugar', value: '$462 / MT', change: '+0.3%', direction: 'up' },
  { name: 'Brent', value: '$79.42', change: '-0.6%', direction: 'down' },
  { name: 'USD / AFN', value: '72.15', change: '+0.12%', direction: 'up' },
  { name: 'USD / AED', value: '3.6725', change: '—', direction: 'flat' },
];

const businessDivisions = [
  {
    number: '01',
    name: 'BKB Trade',
    kicker: 'Cross-border commerce',
    description: 'Connecting established suppliers with commercial buyers through disciplined sourcing, import, export and regional distribution.',
    services: ['Import & export', 'International sourcing', 'Regional distribution', 'Trade facilitation'],
    image: images.port,
    alt: 'Container terminal supporting cross-border trade',
  },
  {
    number: '02',
    name: 'BKB Commodities',
    kicker: 'Essential goods',
    description: 'Reliable movement of staple food commodities for wholesale, commercial and institutional demand across regional markets.',
    services: ['Wheat flour & rice', 'Sugar & salt', 'Corn & sunflower oil', 'Bulk edible oils'],
    image: images.wheat,
    alt: 'Mature wheat growing in a field',
  },
  {
    number: '03',
    name: 'BKB Financial Services',
    kicker: 'Commerce enabled',
    description: 'Practical financial infrastructure supporting business settlement, liquidity, currency exchange and dependable cash distribution.',
    services: ['Currency exchange', 'Commercial settlement', 'Cash distribution', 'Business liquidity'],
    image: images.kabul,
    alt: 'Kabul city with mountains in the distance',
  },
  {
    number: '04',
    name: 'BKB Industrial',
    kicker: 'Operational supply',
    description: 'Procurement and distribution of industrial goods, automotive batteries and managed business services for demanding operators.',
    services: ['Automotive batteries', 'Industrial products', 'Procurement', 'MSP services'],
    image: images.warehouse,
    alt: 'Organized shelving inside a commercial warehouse',
  },
];

const commodities = [
  { name: 'Wheat flour', origin: 'Regional & international', format: '25–50 kg / bulk', terms: 'FCA · CPT · DAP', image: images.wheat, alt: 'Wheat crop representing commercial flour supply' },
  { name: 'Sunflower oil', origin: 'Black Sea region', format: 'PET · drums · flexitank', terms: 'CFR · CPT · DAP', image: images.sunflower, alt: 'Aerial view over a sunflower field' },
  { name: 'Rice', origin: 'South & Central Asia', format: '25–50 kg / bulk', terms: 'FOB · CFR · DAP', image: images.rice, alt: 'Close view of rice grains' },
  { name: 'Sugar', origin: 'International', format: '50 kg / bulk', terms: 'FOB · CFR · DAP', image: images.sugar, alt: 'Backlit refined sugar cubes' },
];

const locations = [
  { name: 'Kabul', sub: 'Group headquarters', x: '36%', y: '52%', major: true },
  { name: 'Istanbul', sub: 'Trade corridor', x: '9%', y: '31%' },
  { name: 'Dubai', sub: 'Regional commerce', x: '32%', y: '78%' },
  { name: 'Almaty', sub: 'Central Asia', x: '53%', y: '22%' },
  { name: 'Tashkent', sub: 'Central Asia', x: '49%', y: '38%' },
  { name: 'Karachi', sub: 'Port access', x: '47%', y: '78%' },
  { name: 'Delhi', sub: 'South Asia', x: '64%', y: '68%' },
  { name: 'Shanghai', sub: 'Sourcing market', x: '89%', y: '50%' },
];

const exchangeRates = [
  { pair: 'USD / AFN', bid: '72.08', ask: '72.22', move: '+0.12%' },
  { pair: 'EUR / USD', bid: '1.0841', ask: '1.0847', move: '-0.08%' },
  { pair: 'AED / AFN', bid: '19.61', ask: '19.67', move: '+0.04%' },
  { pair: 'TRY / USD', bid: '0.0293', ask: '0.0296', move: '-0.17%' },
];

const statistics = [
  { value: 4, suffix: '', label: 'Core business divisions' },
  { value: 15, suffix: '+', label: 'Trade categories' },
  { value: 8, suffix: '', label: 'Regional markets' },
  { value: 20, suffix: '+', label: 'Years of commercial experience' },
];

const insights = [
  { category: 'Market Intelligence', date: '28 August 2026', title: 'Global wheat prices stabilize following stronger harvest outlook', index: '01' },
  { category: 'Commodities', date: '21 August 2026', title: 'Regional sunflower oil supply conditions: a commercial brief', index: '02' },
  { category: 'Trade', date: '14 August 2026', title: 'Afghanistan’s position across the Central Asian trade corridor', index: '03' },
];

const footerNavigation = [
  { title: 'Group', items: ['About BKB', 'Leadership', 'Our Businesses', 'Markets'] },
  { title: 'Trade', items: ['Import & Export', 'Commodities', 'Distribution', 'Industrial Products'] },
  { title: 'Services', items: ['Currency Exchange', 'Cash Distribution', 'Commercial Services', 'MSP Services'] },
  { title: 'Contact', items: ['Business Enquiries', 'Supplier Enquiries', 'Careers', 'Compliance'] },
];

function AnimatedNumber({ value, suffix }: { value: number; suffix: string }) {
  const ref = useRef<HTMLSpanElement>(null);
  const [display, setDisplay] = useState(0);

  useEffect(() => {
    const element = ref.current;
    if (!element) return;
    const observer = new IntersectionObserver(([entry]) => {
      if (!entry.isIntersecting) return;
      const reduce = window.matchMedia('(prefers-reduced-motion: reduce)').matches;
      if (reduce) setDisplay(value);
      else {
        const start = performance.now();
        const duration = 1100;
        const tick = (now: number) => {
          const progress = Math.min((now - start) / duration, 1);
          setDisplay(Math.round(value * (1 - Math.pow(1 - progress, 3))));
          if (progress < 1) requestAnimationFrame(tick);
        };
        requestAnimationFrame(tick);
      }
      observer.disconnect();
    }, { threshold: 0.55 });
    observer.observe(element);
    return () => observer.disconnect();
  }, [value]);

  return <span ref={ref}>{display}{suffix}</span>;
}

export default function Home() {
  const [activeDivision, setActiveDivision] = useState(0);
  const [menuOpen, setMenuOpen] = useState(false);
  const [scrolled, setScrolled] = useState(false);

  useEffect(() => {
    const onScroll = () => setScrolled(window.scrollY > 80);
    onScroll();
    window.addEventListener('scroll', onScroll, { passive: true });

    const elements = Array.from(document.querySelectorAll<HTMLElement>('.reveal'));
    const observer = new IntersectionObserver((entries) => {
      entries.forEach((entry) => entry.isIntersecting && entry.target.classList.add('is-visible'));
    }, { threshold: 0.12, rootMargin: '0px 0px -40px' });
    elements.forEach((element) => observer.observe(element));
    return () => {
      window.removeEventListener('scroll', onScroll);
      observer.disconnect();
    };
  }, []);

  useEffect(() => {
    document.body.style.overflow = menuOpen ? 'hidden' : '';
    return () => { document.body.style.overflow = ''; };
  }, [menuOpen]);

  const active = businessDivisions[activeDivision];

  return (
    <main>
      <div className="utility-bar">
        <div className="utility-inner">
          <span>Kabul <i /> Istanbul <i /> Dubai <i /> Regional Trade Network</span>
          <span className="languages"><b>English</b><button type="button" dir="rtl">دری</button><button type="button" dir="rtl">پښتو</button></span>
        </div>
      </div>

      <header className={`site-header ${scrolled ? 'scrolled' : ''}`}>
        <a className="brand" href="#top" aria-label="BKB home">
          <span className="brand-mark">BKB</span>
          <span className="brand-name">Belal Kabul<br />Bakhtar</span>
        </a>
        <nav aria-label="Primary navigation">
          <a href="#group">Group</a><a href="#businesses">Businesses</a><a href="#trade">Trade</a>
          <a href="#commodities">Commodities</a><a href="#financial">Financial Services</a><a href="#markets">Markets</a><a href="#about">About</a>
        </nav>
        <a className="header-action desktop-enquiry" href="#contact">Business Enquiries <span>↗</span></a>
        <button className="menu-toggle" type="button" aria-label="Open navigation menu" aria-expanded={menuOpen} onClick={() => setMenuOpen(true)}><span /><span /></button>
      </header>

      <div className={`mobile-menu ${menuOpen ? 'open' : ''}`} aria-hidden={!menuOpen}>
        <div className="mobile-menu-top"><span className="brand-mark">BKB</span><button type="button" onClick={() => setMenuOpen(false)} aria-label="Close navigation menu">Close ×</button></div>
        <nav aria-label="Mobile navigation">
          {['Group', 'Businesses', 'Trade', 'Commodities', 'Financial Services', 'Markets', 'About', 'Contact'].map((item, index) => <a key={item} href={`#${item.toLowerCase().replace('financial services', 'financial').replace(' ', '-')}`} onClick={() => setMenuOpen(false)}><span>0{index + 1}</span>{item}</a>)}
        </nav>
        <div className="mobile-menu-bottom"><span>Kabul · Istanbul · Dubai</span><a href="mailto:business@bkb-group.com">business@bkb-group.com</a></div>
      </div>

      <section className="hero" id="top">
        <div className="hero-copy reveal is-visible">
          <p className="eyebrow"><span /> Belal Kabul Bakhtar</p>
          <h1>Trade that moves<br />across borders.<br /><em>Businesses built<br />to endure.</em></h1>
          <p className="hero-lede">BKB connects markets across Afghanistan and the wider region through commodity trading, financial services, distribution and cross-border commerce.</p>
          <div className="hero-actions">
            <a className="primary-button" href="#group">Explore BKB <span>↓</span></a>
            <a className="text-link" href="#businesses">Our Businesses <span>→</span></a>
          </div>
        </div>

        <div className="hero-visual image-reveal reveal is-visible">
          <img src={images.port} alt="Aerial view of a large container port and its logistics operations" />
          <div className="image-wash" />
          <div className="network-panel">
            <p>Operating network</p>
            <ol><li><span>01</span> Afghanistan</li><li><span>02</span> Türkiye</li><li><span>03</span> UAE</li><li><span>04</span> Central Asia</li></ol>
          </div>
          <div className="hero-coordinate">34.5553° N&nbsp;&nbsp; 69.2075° E</div>
        </div>
      </section>

      <section className="market-strip" aria-label="Indicative international market data">
        <div className="market-label"><span className="pulse" /> <b>Market desk</b><small>Indicative demo data · 28 Aug 2026</small></div>
        <div className="ticker-window">
          <div className="ticker-track">
            {[...marketPrices, ...marketPrices].map((market, index) => <div className="market-item" key={`${market.name}-${index}`}><span>{market.name}</span><strong>{market.value}</strong><em className={market.direction}>{market.change}</em></div>)}
          </div>
        </div>
      </section>

      <section className="group-statement section-shell motif" id="group">
        <div className="section-index reveal"><span>01</span><b>The Group</b></div>
        <div className="statement-grid">
          <h2 className="display-title reveal">One group.<br /><em>Multiple engines</em><br />of commerce.</h2>
          <div className="statement-copy reveal">
            <p>BKB operates across the industries that keep markets moving—from essential food commodities and international trade to financial services, cash distribution and industrial products.</p>
            <div className="crossroads-note"><span>Crossroads of trade</span><strong>Afghanistan</strong><small>Connecting South Asia, Central Asia and the Gulf</small></div>
          </div>
        </div>
      </section>

      <section className="business-section" id="businesses">
        <div className="section-shell">
          <div className="business-heading reveal"><div><div className="section-index light"><span>02</span><b>Business Divisions</b></div><h2>Commercial capabilities,<br /><em>working as one.</em></h2></div><p>Four focused divisions. One established operating group.</p></div>
          <div className="division-interface reveal">
            <div className="division-tabs" role="tablist" aria-label="BKB business divisions">
              {businessDivisions.map((division, index) => <button key={division.name} type="button" role="tab" aria-selected={activeDivision === index} className={activeDivision === index ? 'active' : ''} onClick={() => setActiveDivision(index)} onMouseEnter={() => setActiveDivision(index)} onFocus={() => setActiveDivision(index)}><span>{division.number}</span><b>{division.name}</b><i>→</i></button>)}
            </div>
            <div className="division-stage" role="tabpanel">
              {businessDivisions.map((division, index) => <img key={division.name} src={division.image} alt={activeDivision === index ? division.alt : ''} aria-hidden={activeDivision !== index} className={activeDivision === index ? 'active' : ''} />)}
              <div className="division-overlay" />
              <div className="division-detail" key={active.name}>
                <p>{active.kicker}</p><h3>{active.name}</h3><span>{active.description}</span>
                <ul>{active.services.map((service) => <li key={service}>{service}</li>)}</ul>
              </div>
            </div>
          </div>
        </div>
      </section>

      <section className="commodities-section section-shell" id="commodities">
        <div className="commodity-intro reveal"><div className="section-index"><span>03</span><b>Physical Commodities</b></div><h2 className="display-title">From source<br /><em>to market.</em></h2><p>Disciplined procurement and dependable distribution of essential food commodities for commercial and institutional buyers.</p></div>
        <div className="commodity-mosaic">
          {commodities.map((commodity, index) => <article className={`commodity-tile tile-${index + 1} image-reveal reveal`} key={commodity.name}>
            <img src={commodity.image} alt={commodity.alt} />
            <div className="commodity-shade" />
            <div className="commodity-label"><span>0{index + 1}</span><h3>{commodity.name}</h3><p>{index === 0 ? 'Reliable sourcing and distribution for commercial and institutional buyers.' : index === 1 ? 'Regional procurement across established agricultural corridors.' : index === 2 ? 'Bulk and wholesale supply in adaptable formats.' : 'International sourcing for consistent commercial supply.'}</p></div>
            <dl><div><dt>Origin</dt><dd>{commodity.origin}</dd></div><div><dt>Supply format</dt><dd>{commodity.format}</dd></div><div><dt>Trade terms</dt><dd>{commodity.terms}</dd></div></dl>
          </article>)}
        </div>
        <div className="commodity-foot reveal"><span>Also supplied</span><p>Corn oil · Edible oils · Salt · Specialty food products</p><a href="#contact">Discuss commodity supply <b>→</b></a></div>
      </section>

      <section className="network-section" id="markets">
        <div className="section-shell network-grid">
          <div className="network-copy reveal"><div className="section-index light"><span>04</span><b>Regional Network</b></div><h2>Built in Kabul.<br /><em>Connected to<br />regional markets.</em></h2><p>Afghanistan has always stood at the meeting point of trading cultures. BKB carries that commercial position forward—linking suppliers, buyers and operating partners across established regional corridors.</p><div className="network-legend"><span><i className="dot-primary" />Group base</span><span><i />Trade market</span><span><b>Demo footprint—not office locations</b></span></div></div>
          <div className="trade-map reveal" aria-label="Illustrative regional trade network">
            <div className="map-grid" />
            <div className="route r1" /><div className="route r2" /><div className="route r3" /><div className="route r4" /><div className="route r5" /><div className="route r6" /><div className="route r7" />
            {locations.map((location) => <div className={`map-node ${location.major ? 'major' : ''}`} style={{ left: location.x, top: location.y }} key={location.name}><i /><span><b>{location.name}</b><small>{location.sub}</small></span></div>)}
            <span className="map-coordinate top">38° N</span><span className="map-coordinate bottom">24° N</span><span className="map-coordinate right">121° E</span>
          </div>
        </div>
      </section>

      <section className="financial-section" id="financial">
        <div className="financial-rule"><span>05 / Financial Services</span><b>Institutional capability</b></div>
        <div className="section-shell financial-grid">
          <div className="financial-copy reveal"><p className="blue-label">BKB Financial Services</p><h2>Financial<br />infrastructure<br /><em>for commerce.</em></h2><p>Supporting the practical flow of business through currency exchange, commercial settlement, regional payment support and cash distribution.</p><a href="#contact" className="dark-link">Explore financial services <span>→</span></a></div>
          <div className="rate-board reveal">
            <div className="rate-head"><div><span className="pulse" /> Market reference</div><small>Illustrative demo rates · 14:42 GST</small></div>
            <div className="rate-columns"><span>Pair</span><span>Bid</span><span>Ask</span><span>Move</span></div>
            {exchangeRates.map((rate) => <div className="rate-row" key={rate.pair}><strong>{rate.pair}</strong><span>{rate.bid}</span><span>{rate.ask}</span><em className={rate.move.startsWith('+') ? 'positive' : 'negative'}>{rate.move}</em></div>)}
            <p className="rate-disclaimer">Reference values are hardcoded for this visual demonstration and do not constitute an offer to transact.</p>
          </div>
          <div className="service-ledger reveal">
            {['Currency exchange', 'Commercial settlement', 'Cash distribution', 'Regional payment support', 'Business liquidity services'].map((service, index) => <div key={service}><span>0{index + 1}</span><b>{service}</b><i>↗</i></div>)}
          </div>
        </div>
      </section>

      <section className="scale-section section-shell" id="about">
        <div className="scale-intro reveal"><div className="section-index"><span>06</span><b>Scale & Experience</b></div><h2>Built on the work.<br /><em>Measured by continuity.</em></h2></div>
        <div className="statistics reveal">
          {statistics.map((stat, index) => <div className="stat" key={stat.label}><span className="stat-index">0{index + 1}</span><strong><AnimatedNumber value={stat.value} suffix={stat.suffix} /></strong><p>{stat.label}</p></div>)}
        </div>
        <p className="demo-note">Illustrative demonstration figures—structured for straightforward replacement with verified company data.</p>
      </section>

      <section className="trade-story" id="trade">
        <img src={images.freight} alt="Freight truck moving through a mountainous regional trade corridor" />
        <div className="story-shade" />
        <div className="story-content reveal"><span>Reliability / 07</span><h2>Commerce is ultimately<br /><em>about reliability.</em></h2><p>Moving essential goods across borders depends on disciplined sourcing, clear communication and supplier and distribution networks built for continuity.</p><a href="#contact">Work with BKB <b>↗</b></a></div>
        <div className="story-caption"><span>Regional freight corridor</span><span>Illustrative image / 2026</span></div>
      </section>

      <section className="insights-section section-shell">
        <div className="insights-head reveal"><div><div className="section-index"><span>08</span><b>Market Intelligence</b></div><h2>Commercial perspective<br /><em>from the region.</em></h2></div><a href="#insights">View all intelligence <span>→</span></a></div>
        <div className="insight-list" id="insights">
          {insights.map((insight) => <article className="insight-row reveal" key={insight.index}><span className="insight-number">{insight.index}</span><div className="insight-meta"><b>{insight.category}</b><time>{insight.date}</time></div><h3>{insight.title}</h3><a href="#contact" aria-label={`Read ${insight.title}`}>↗</a></article>)}
        </div>
      </section>

      <section className="enquiry-section" id="contact">
        <div className="enquiry-pattern" />
        <div className="section-shell enquiry-grid reveal"><div><span className="blue-label">Business enquiries</span><h2>Let’s discuss<br /><em>business.</em></h2></div><div className="enquiry-copy"><p>For sourcing, distribution, commodity supply, financial services or strategic partnerships, speak with the BKB commercial team.</p><div><a className="primary-button" href="mailto:business@bkb-group.com">Start an enquiry <span>↗</span></a><a className="text-link" href="tel:+93700000000">Contact BKB <span>→</span></a></div><small>Typical response within two business days</small></div></div>
      </section>

      <footer>
        <div className="footer-watermark" aria-hidden="true">BKB</div>
        <div className="section-shell footer-main">
          <div className="footer-brand"><a className="brand" href="#top"><span className="brand-mark">BKB</span><span className="brand-name">Belal Kabul<br />Bakhtar</span></a><p>A diversified Afghan business group active across international trade, commodities, financial services and distribution.</p><div className="footer-locations"><span>Kabul</span><span>Istanbul</span><span>Dubai</span></div></div>
          <div className="footer-navigation">{footerNavigation.map((column) => <div key={column.title}><h3>{column.title}</h3>{column.items.map((item) => <a href="#contact" key={item}>{item}</a>)}</div>)}</div>
        </div>
        <div className="section-shell footer-contact"><span>Commercial desk</span><a href="mailto:business@bkb-group.com">business@bkb-group.com</a><span>+93 700 000 000</span></div>
        <div className="section-shell footer-bottom"><span>© 2026 Belal Kabul Bakhtar. Demonstration website.</span><div><a href="#">Privacy</a><a href="#">Terms</a><a href="#">Compliance</a></div><a href="#top">Back to top ↑</a></div>
      </footer>
    </main>
  );
}
